describe('UI Rendering', () => {
  it('Shows hero wave and overlapping circle on landing', () => {
    cy.visit('/');
    cy.get('svg').should('exist');
    cy.get('div[aria-hidden="true"]').should('exist');
  });

  it('Navbar visible on login and landing', () => {
    cy.visit('/');
    cy.contains('TicketApp');
    cy.visit('/auth/login');
    cy.contains('TicketApp');
  });
});
