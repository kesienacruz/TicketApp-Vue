function login() {
  cy.visit('/auth/login');
  cy.get('input#email').type('test@ticketapp.test');
  cy.get('input#password').type('password123');
  cy.contains('button', 'Sign in').click();
  cy.location('pathname').should('include', '/dashboard');
}

describe('Ticket CRUD', () => {
  it('Creates, edits, and deletes a ticket', () => {
    login();
    cy.visit('/tickets');

    // Create
    cy.contains('+ New Ticket').click();
    cy.get('input#ticket-title').type('Printer jam on floor 2');
    cy.get('textarea#ticket-description').type('Happens when printing labels.');
    cy.get('select#ticket-status').select('in_progress');
    cy.contains('button', 'Create ticket').click();
    cy.contains('Ticket created.');

    // Should display card
    cy.contains('Printer jam on floor 2').should('exist');
    cy.contains('Happens when printing labels.').should('exist');
    cy.get('span').contains('in_progress').should('have.class', 'bg-amber-500');

    // Edit
    cy.contains('article', 'Printer jam on floor 2').within(() => {
      cy.contains('Edit').click();
    });
    cy.get('input#ticket-title').clear().type('Printer jam (updated)');
    cy.get('select#ticket-status').select('closed');
    cy.contains('button', 'Save changes').click();
    cy.contains('Ticket updated.');
    cy.contains('Printer jam (updated)').should('exist');
    cy.get('span').contains('closed').should('have.class', 'bg-gray-400');

    // Delete
    cy.contains('article', 'Printer jam (updated)').within(() => {
      cy.contains('Delete').click();
    });
    cy.contains('Confirm delete').click();
    cy.contains('Printer jam (updated)').should('not.exist');
  });
});
