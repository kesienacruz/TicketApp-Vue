describe('Auth and redirect', () => {
  it('Redirects unauthorized user from /dashboard to /auth/login with assertive message', () => {
    cy.visit('/dashboard');
    cy.location('pathname').should('include', '/auth/login');
    cy.get('#toast-live-assertive').should('contain', 'Your session has expired — please log in again.');
  });

  it('Logs in with test credentials and lands on dashboard', () => {
    cy.visit('/auth/login');
    cy.get('input#email').type('test@ticketapp.test');
    cy.get('input#password').type('password123');
    cy.contains('button', 'Sign in').click();
    cy.location('pathname').should('include', '/dashboard');
    cy.get('body').contains('Quick snapshot of your tickets');
  });
});
